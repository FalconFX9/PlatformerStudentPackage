

class ShaderException(Exception):
    """ Exception class for shader-specific problems. """
    pass
